﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace TextRank
{
    class TextRankKeyWord
    {
        struct WeightStruct
        {
            public double dWeight;
            public int nIndex;
        }

        static double P_d = 0.85; //阻尼系数
        static int Max_IteratorNum = 100;//迭代次数
        static int WindowSize = 5; //筛选窗口
        private string strInput = null; //输入字符串
        private Dictionary<string,int> KeyWordList = new Dictionary<string,int>(); //关键词map
        private int[,] MatrixNeighbor; //关键词邻接矩阵
        private WeightStruct[] WeightV; //关键词的权值列表

        public string TextRankKeyWordCompute(string str) //输入关键词,返回提取的关键词
        {
            strInput = str;           
            string[] strList= str.Split('/');
            int nCounter = 0;
            for(int i = 0; i < strList.Length; i++)
            {
                if(KeyWordList.ContainsKey(strList[i]) == false)
                {
                    KeyWordList.Add(strList[i],nCounter);
                    nCounter++;
                }
            }
            WeightV = new WeightStruct[KeyWordList.Count]; //创建权值表
            for (int i = 0; i < KeyWordList.Count; i++)
            {
                WeightV[i].nIndex = i;
                WeightV[i].dWeight = 1;
            }
            TextRankKeyWordMartrix();
            TextRankKeyWordMartrixIterationVote();
            return TextRankKeyWordOutput();
        }
        private ArrayList TextRankKeyWordSelect(string str)
        {
            ArrayList sResultList = new ArrayList();
            string[] strList = strInput.Split('/');
            
            for(int i = 0; i < strList.Length; i++)
            {
                if(strList[i] == str) //查找到当前的词,读取当前位置的前后WindowSIze个词
                {                    
                    //先往搜索
                    int nFront = 0;
                    if(i - WindowSize <=0 )
                        nFront = 0;
                    else
                        nFront = i - WindowSize;
                    for(int j = nFront; j < i; j++)
                        sResultList.Add(strList[j]);
                    //往后搜索
                    int nBack = 0;
                    if(i + WindowSize >=strList.Length)
                        nBack = strList.Length;
                    else
                        nBack = i + WindowSize;
                    for(int j = i; j< nBack; j++)
                        sResultList.Add(strList[j]);

                }
            }
            return sResultList;
        }
        public void TextRankKeyWordMartrix() //构建邻接矩阵
        {
            int nMartrix = KeyWordList.Count;
            MatrixNeighbor = new int[nMartrix, nMartrix]; //构建邻接矩阵

            foreach(KeyValuePair<string, int> kvp  in KeyWordList)
            {
                //获取当前词的行id
                var vRow = from d in KeyWordList where d.Key == kvp.Key select d.Value; //查找当前键值的行
                int nRow = vRow.First();
                //获取当前词的前后关联词汇
                ArrayList listtemp = TextRankKeyWordSelect(kvp.Key);

                //依次给当前的关联词汇所在的列赋值
                for (int i = 0; i < listtemp.Count; i++)
                {
                    var vCol = from d in KeyWordList where d.Key == listtemp[i].ToString() select d.Value;
                    int nCol = vCol.First();
                    if (listtemp[i].ToString() != kvp.Key)
                    {
                        //查找匹配词的列id                        
                        MatrixNeighbor[Convert.ToInt16(nRow), Convert.ToInt16(nCol)] = 1;
                    }
                    else
                        MatrixNeighbor[Convert.ToInt16(nRow), Convert.ToInt16(nCol)] = 0;
                }
            }
        }
        public void TextRankKeyWordMartrixIterationVote() //迭代计算权值
        {
            for (int k = 0; k < Max_IteratorNum; k++)
            {
                foreach (KeyValuePair<string, int> kvp in KeyWordList)
                {
                    var vRow = from d in KeyWordList where d.Key == kvp.Key select d.Value; //查找当前键值的行

                    int nRow = vRow.First();
                    double nResult = 0;
                    for (int i = 0; i < KeyWordList.Count; i++) //计算入边
                    {
                        if (MatrixNeighbor[Convert.ToInt16(nRow), i] == 1)  //有边
                        {
                            double dOUt = 0;
                            for (int j = 0; j < KeyWordList.Count; j++) //出边求和
                                dOUt = dOUt + MatrixNeighbor[j, i];
                            if (dOUt == 0)
                                dOUt = 1;
                            nResult = nResult + WeightV[i].dWeight * 1 / dOUt;
                        }
                    }
                    WeightV[Convert.ToInt16(nRow)].dWeight = (1 - P_d) + P_d * nResult; //计算该点的值
                }
            }
        }
        public string TextRankKeyWordOutput() //输出权值最高的几个词
        {
            string strResult = null;
            WeightStruct[] IndexMax5 = WeightV.OrderBy(x => x.dWeight).Skip(WeightV.Length - 5).ToArray();
            for (int i = 4; i >= 0; i--)
            {
                foreach(KeyValuePair<string, int> kvp  in KeyWordList)
                {
                    if (kvp.Value == IndexMax5[i].nIndex)
                        strResult = strResult + kvp.Key + "/";
                }
            }
            strResult = strResult.Substring(0, strResult.Length - 1);
            return strResult;
        }



    }


}


