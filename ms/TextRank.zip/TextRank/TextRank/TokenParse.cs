﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace TextRank
{
    //词典树节点结构
    class TireNode
    {
        public string NodeValue;    //节点值
        public int nRefNum;          //查找次数
        public bool bIsWord;               //从根节点到该节点是否构成一个词汇
        public Dictionary<int, TireNode> ChildNodeSet; //节点集

        public TireNode()
        {
            NodeValue = null;
            nRefNum = -1;
            bIsWord = false;
            ChildNodeSet = new Dictionary<int,TireNode>();
        }
    };


    //分词类
    class TokenParse
    {
        public TokenParse()
        {
            mRoot = new TireNode();
        }
        ~TokenParse()
        {

        }
        private TireNode mRoot = new TireNode(); //词典树根节点

        public void InsertNode(string strToken) //插入节点
        {
            InsertInnerNode(ref mRoot, strToken);
        }
        public bool MatchToken(string strToken)
        {
            return MatchInnerToken(ref mRoot, strToken);
        }
        public string FrontMaxMatchString(ref string strToken) //最大正向匹配
        {
            string strtemp = null;
            FrontMaxInnerMatchString(ref mRoot,ref strToken,ref strtemp);
            return  strtemp;
        }
        //内部函数
        private void InsertInnerNode(ref TireNode parentNode,string strToken)
        {
            if (strToken.Length <= 0)
            {
                parentNode.bIsWord = true;
                return;
            }
            else
            {
                string FirstWord = GetFirstChar(ref strToken);
                int nIndex = GetWordId(FirstWord);
                if (nIndex >= 0x4E00 && nIndex <= 0x9FA5)
                {
                    if (parentNode.ChildNodeSet.ContainsKey(nIndex)) //存在该字符
                    {
                        TireNode nodetemp = parentNode.ChildNodeSet[nIndex];
                        InsertInnerNode(ref nodetemp, strToken);
                    }
                    else
                    {
                        TireNode nodeTemp = new TireNode();
                        nodeTemp.NodeValue = FirstWord;
                        InsertInnerNode(ref nodeTemp,strToken);
                        parentNode.ChildNodeSet.Add(nIndex,nodeTemp);
                    }
                }
                else
                {
                    return;
                }
            }
        }
        private bool MatchInnerToken(ref TireNode parentNode, string strToken)
        {
            if (strToken.Length <= 0)
            {
                if (parentNode.bIsWord == true)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                string FirstWord = GetFirstChar(ref strToken);
                int nIndex = GetWordId(FirstWord);
                if (nIndex>=0x4E00&&nIndex<=0x9FA5)
                {
                    if (parentNode.ChildNodeSet.ContainsKey(nIndex)) //存在该字符
                    {
                        TireNode nodetemp = parentNode.ChildNodeSet[nIndex];
                        return MatchInnerToken(ref nodetemp,strToken);
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
        }
        private void FrontMaxInnerMatchString(ref TireNode parentNode,ref string strToken,ref string strResult)
        {
            if (parentNode.ChildNodeSet.Count<=0||strToken.Length<=0)
            {
                return;
            }
            else
            {
                string FirstWord = GetFirstChar(ref strToken);
                int nIndex = GetWordId(FirstWord);
                if (nIndex>=0x4E00&&nIndex<=0x9FA5)
                {
                    if (parentNode.ChildNodeSet.ContainsKey(nIndex)) //存在该字符
                    {
                        strResult = strResult + FirstWord;
                        TireNode nodetemp = parentNode.ChildNodeSet[nIndex];
                        FrontMaxInnerMatchString(ref nodetemp,ref strToken,ref strResult);
                    }
                    else
                    {
                        strToken = FirstWord+strToken;
                        string strtemp = strResult;
                        string strFront = null;
                        FindFrontMax(ref strtemp,ref strFront);
                        strToken = strtemp+strToken;
                        strResult = strFront;

                        return;
                    }

                }
                else
                {
                    return;
                }
            }
        }
        private void FindFrontMaxInnerMatchString(ref TireNode parentNode,ref string strToken,ref string strFirstToken)
        {
            if (parentNode.ChildNodeSet.Count<=0||strToken.Length<=0)
            {
                return;
            }
            string FirstWord = GetFirstChar(ref strToken);
            int nIndex = GetWordId(FirstWord);
            if (nIndex>=0x4E00&&nIndex<=0x9FA5)
            {
                
                if (parentNode.ChildNodeSet.ContainsKey(nIndex)) //存在该字符
                {                
                    TireNode nodetemp = parentNode.ChildNodeSet[nIndex];
                    if (nodetemp.bIsWord!=true)
                    {
                       strToken = FirstWord+strToken;
                       return ;
                    }
                    else
                    {
                        strFirstToken = strFirstToken + FirstWord;
                        FindFrontMaxInnerMatchString(ref nodetemp,ref strToken,ref strFirstToken);
                     }
                }
                else
                {
                   return  ;
                }
            }
        }
        private void FindFrontMax(ref string strToken,ref string strFirstToken)
        {
            FindFrontMaxInnerMatchString(ref mRoot,ref strToken,ref strFirstToken);
        }
        //辅助函数
        private string GetFirstChar(ref string strWord) //获取首字符
        {
            string tempWord;
            if (strWord.Length > 0)
            {
                tempWord = strWord[0].ToString();
                strWord = strWord.Substring(1, strWord.Length - 1);
            }
            else
            {
                tempWord = null;
            }
            return tempWord;
        }
        private int GetWordId(string strWord) //获取字符ID
        {
            int nResult = Convert.ToInt32(strWord[0]);
            return nResult;
        }








    }
}
