﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Text.RegularExpressions;

namespace TextRank
{
    class TextRankAbstract
    {
        struct WeightStruct
        {
            public double dWeight;
            public int nIndex;            
        }

        static double P_d = 0.85; //阻尼系数
        static double P_k1 = 3; //Bm25算法的调节系数 1.4系数
        //static double P_k2 = 0.25; //Bm25算法的调节系数 1.4系数
        static double P_b = 0.15; //Bm25算法的调节系数
        static int Max_IteratorNum = 100;//迭代次数
        string strInputtemp;

        private Dictionary<string, int> SentenceList = new Dictionary<string, int>(); //句子列表
        //private int[,] MatrixNeighbor; //摘要句子邻接矩阵  为全连接，所以邻接矩阵值为全1
        private double[,] MatrixWeight; //权值矩阵
        private WeightStruct[] WeightV; //摘要句子的权值列表
        public string[] TokenList; //分词表集合

        public void TextRankAbstractCompute(string str) //输入文章,返回提取的摘要句子
        {
            strInputtemp = str;
            string valEx = @"，|。|；";
            string[] strOrgin = Regex.Split(str, valEx); //分割句子
            int nCounter = 0;
            for (int i = 0; i < strOrgin.Length-1; i++)
            {
                if (SentenceList.ContainsKey(strOrgin[i]) == false)
                {
                    SentenceList.Add(strOrgin[i], nCounter);
                   
                    nCounter++;
                }
            }
            TokenList = new string[SentenceList.Count]; //分词表
            WeightV = new WeightStruct[SentenceList.Count]; //创建权值表
            for (int i = 0; i < SentenceList.Count; i++)
            {
                WeightV[i].nIndex = i;
                WeightV[i].dWeight = 1;
                TokenList[i] = strOrgin[i];
            }

        }
        public string TextRankAbstractCutSentence(string strSentence)
        {
            string sResut = null;
            return sResut;
        }
        public double TextRankAbstractBm25Score(string sSql, string sDoc) //计算两个句子的相似度
        {
            double dScore = 0;
            var vSql = from d in SentenceList where d.Key == sSql select d.Value; //查找当前键值的行
            int nSql = vSql.First();
            var vDoc = from d in SentenceList where d.Key == sDoc select d.Value; //查找当前键值的行
            int nDoc = vDoc.First();
            //获取Tokenlist
            string[] SqlList = TokenList[nSql].Split('/');
            string[] DocList = TokenList[nDoc].Split('/');

            for (int i = 0; i < SqlList.Length; i++)
            {
                double Idf = Math.Log10((SentenceList.Count - TextRankAbstractBm25ScoreContain(SqlList[i]) + 0.5) / (TextRankAbstractBm25ScoreContain(SqlList[i]) + 0.5));

                //double Rqd1 = (TextRankAbstractBm25ScoreFreq(SqlList[i], sDoc) / (double)DocList.Length) * (1.0 + P_k1) / ((TextRankAbstractBm25ScoreFreq(SqlList[i], sDoc) / (double)DocList.Length) + P_k1 * (1.0 - P_b + P_b *((double)sDoc.Length / (double)strInputtemp.Length * (double)SentenceList.Count)));
                //double Rqd2 = (TextRankAbstractBm25ScoreFreq(SqlList[i], sSql) / (double)SqlList.Length) * (1.0 + P_k2) / ((TextRankAbstractBm25ScoreFreq(SqlList[i], sSql) / (double)SqlList.Length) + P_k2);
                double Rqd1 = (TextRankAbstractBm25ScoreFreq(SqlList[i], sDoc)) * (1.0 + P_k1) / ((TextRankAbstractBm25ScoreFreq(SqlList[i], sDoc) ) + P_k1 * (1.0 - P_b + P_b *((double)sDoc.Length / (double)strInputtemp.Length * (double)SentenceList.Count)));
                dScore += Idf * Rqd1;
            }
            return dScore;
        }
        private double TextRankAbstractBm25ScoreFreq(string sToken, string sDoc) // 查询词汇在句子中的出线的频率
        {
            if (string.IsNullOrEmpty(sToken))
                return 0;

            int counter = 0;
            int index = sDoc.IndexOf(sToken, 0);
            while (index >= 0 && index < sDoc.Length)
            {
                counter++;
                index = sDoc.IndexOf(sToken, index + sToken.Length);
            }
            return counter;
        }
        private int TextRankAbstractBm25ScoreContain(string sToken) // 查询词汇在句子中的是否出现
        {
            int nResult = 0;
            
            foreach (KeyValuePair<string, int> kvp in SentenceList)
            {
                if (kvp.Key.IndexOf(sToken) >= 0)
                    nResult++;
            }
            return nResult;
        }

        public void TextRankAbstractMartrix() //构建邻接矩阵
        {
            int nMartrix = SentenceList.Count;            
            MatrixWeight = new double[nMartrix, nMartrix]; //构建权值矩阵

            foreach (KeyValuePair<string, int> kvpR in SentenceList)
            {
                //获取当前词的行id
                var vRow = from d in SentenceList where d.Key == kvpR.Key select d.Value; //查找当前键值的行
                int nRow = vRow.First();

                foreach (KeyValuePair<string, int> kvpC in SentenceList)
                {
                    var vCol = from d in SentenceList where d.Key == kvpC.Key select d.Value; //查找当前键值的列
                    int nCol = vCol.First();
                    if (kvpR.Key != kvpC.Key)
                    {
                        MatrixWeight[nRow, nCol] = TextRankAbstractBm25Score(kvpC.Key, kvpR.Key);
                    }
                    else
                        MatrixWeight[nRow, nCol] = 0;
                }
            }
        }
        public void TextRankAbstractMartrixIterationVote() //迭代计算权值
        {
            for (int k = 0; k < Max_IteratorNum; k++)
            {
                foreach (KeyValuePair<string, int> kvp in SentenceList)
                {
                    var vRow = from d in SentenceList where d.Key == kvp.Key select d.Value; //查找当前键值的行

                    int nRow = vRow.First();
                    double nResult = 0;
                    for (int i = 0; i < SentenceList.Count; i++) //计算入边
                    {
                        double dOUt = 0;
                        for (int j = 0; j < SentenceList.Count; j++) //出边求和
                            dOUt = dOUt + MatrixWeight[j, i];
                        if (dOUt == 0)
                            dOUt = 1;

                        nResult = nResult + WeightV[i].dWeight * MatrixWeight[nRow,i] / dOUt;
                    }
                    WeightV[Convert.ToInt16(nRow)].dWeight = (1 - P_d) + P_d * nResult; //计算该点的值
                }
            }
        }
        public string TextRankKeyWordOutput() //输出权值最高的几个句子
        {
            string strResult = null;
            WeightStruct[] IndexMax5 = WeightV.OrderBy(x => x.dWeight).Skip(WeightV.Length - 5).ToArray();
            for (int i = 4; i >= 0; i--)
            {
                foreach (KeyValuePair<string, int> kvp in SentenceList)
                {
                    if (kvp.Value == IndexMax5[i].nIndex)
                        strResult = strResult + kvp.Key + "/";
                }
            }
            strResult = strResult.Substring(0, strResult.Length - 1);
            return strResult;
        }

    }
}
