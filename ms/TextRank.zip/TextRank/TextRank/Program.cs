﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;

namespace TextRank
{
    class Program
    {
        static void Main(string[] args)
        {
            //关键词测试
            //TextRankKeyWord textKeyW = new TextRankKeyWord();
            //string sResult = textKeyW.TextRankKeyWordCompute("程序员/英文/程序/开发/维护/专业/人员/程序员/分为/程序/设计/人员/程序/编码/人员/界限/特别/中国/软件/人员/分为/程序员/高级/程序员/系统/分析员/项目/经理");

            //摘要测试
            //TextRankAbstract textAbstract = new TextRankAbstract();
            //string sInput = "算法可大致分为基本算法、数据结构的算法、数论算法、计算几何的算法、图的算法、动态规划以及数值分析、加密算法、排序算法、检索算法、随机化算法、并行算法、厄米变形模型、随机森林算法。"
            //                        +"算法可以宽泛的分为三类。"
            //                        + " 一，有限的确定性算法，这类算法在有限的一段时间内终止。他们可能要花很长时间来执行指定的任务，但仍将在一定的时间内终止。这类算法得出的结果常取决于输入值。"
            //                        + "二，有限的非确定算法，这类算法在有限的时间内终止。然而，对于一个（或一些）给定的数值，算法的结果并不是唯一的或确定的。"
            //                        + "三，无限的算法，是那些由于没有定义终止定义条件，或定义的条件无法由输入的数据满足而不终止运行的算法。通常，无限算法的产生是由于未能确定的定义终止条件。";
            //textAbstract.TextRankAbstractCompute(sInput);
            //textAbstract.TokenList[0] = "算法/大致/分/基本/算法/数据/结构/算法/数论/算法/计算/几何/算法/图/算法/动态/规划/数值/分析/加密/算法/排序/算法/检索/算法/随机/化/算法/并行/算法/厄/米/变形/模型/随机/森林/算法";
            //textAbstract.TokenList[1] = "算法/宽泛/分为/三类";
            //textAbstract.TokenList[2] = "一";
            //textAbstract.TokenList[3] = "有限/确定性/算法";
            //textAbstract.TokenList[4] = "类/算法/有限/一段/时间/终止";
            //textAbstract.TokenList[5] = "可能/花/长/时间/执行/指定/任务";
            //textAbstract.TokenList[6] = "一定/时间/终止";
            //textAbstract.TokenList[7] = "类/算法/得出/常/取决/输入/值";
            //textAbstract.TokenList[8] = "二";
            //textAbstract.TokenList[9] = "有限/非/确定/算法";
            //textAbstract.TokenList[10] = "类/算法/有限/时间/终止";
            //textAbstract.TokenList[11] = "然而";
            //textAbstract.TokenList[12] = "一个/定/数值";
            //textAbstract.TokenList[13] = "算法/唯一/确定";
            //textAbstract.TokenList[14] = "三";
            //textAbstract.TokenList[15] = "无限/算法";
            //textAbstract.TokenList[16] = "没有/定义/终止/定义/条件";
            //textAbstract.TokenList[17] = "定义/条件/无法/输入/数据/满足/终止/运行/算法";
            //textAbstract.TokenList[18] = "通常";
            //textAbstract.TokenList[19] = "无限/算法/产生/未/确定/定义/终止/条件";

            //textAbstract.TextRankAbstractMartrix();
            //textAbstract.TextRankAbstractMartrixIterationVote();
            //string str = textAbstract.TextRankKeyWordOutput();

            //Console.WriteLine(str);

            //分词测试
            TokenParse TParser = new TokenParse();
            StreamReader fr = new StreamReader("F:\\资料\\词典\\分词表U.txt");
            string strline = null;
            while ((strline = fr.ReadLine()) != null)
            {
                TParser.InsertNode(strline);
            }
            fr.Close();
            string  strtemp ="短文并不是一种文学体裁。因而以前并没有短文这一提法。近年来由于社会日新月异的发展，人们的生活节奏加快了，催生了对于短篇幅文章的大量需求。所以，短文才被提到一个崭新的高度，进入到人们的视野。现代文学的大类分为小说、戏剧、诗歌和散文。这里的散文指广义散文，每一类作品的篇幅被压缩之后就成了短文。但由于自身的特性和社会的需求，戏剧类短文相对少见。因而短文主要涵盖小说、诗歌和散文。由于记叙文、论说文、说明文、杂文等文学体裁和报道、广告、总结等应用文体裁都属于广义散文里面的范畴，因而也同样被短文所涵盖。总之，只要篇幅够短就是短文";

            //string strTokenList = null;
            //while (strtemp.Length > 0)
            //{
            //    string  str = TParser.FrontMaxMatchString(ref strtemp);
            //    if (str != "的" && str != "和" && str != "与" && str != "因而" && str != "由于")
            //    strTokenList = strTokenList + str + "/";
            //}

            //TextRankKeyWord textKeyW = new TextRankKeyWord();
            //string sResult = textKeyW.TextRankKeyWordCompute(strTokenList);


            //分词加摘要测试
            TextRankAbstract textAbstract = new TextRankAbstract();
            textAbstract.TextRankAbstractCompute(strtemp);
            for (int i = 0; i < textAbstract.TokenList[i].Length; i++)
            {
                string strTokenList = textAbstract.TokenList[i];
                while (strtemp.Length > 0)
                {
                    string str = TParser.FrontMaxMatchString(ref strtemp);
                    if (str != "的" && str != "和" && str != "与" && str != "因而" && str != "由于")
                        strTokenList = strTokenList + str + "/";
                }
                textAbstract.TokenList[i] = strTokenList;
            }
            textAbstract.TextRankAbstractMartrix();
            textAbstract.TextRankAbstractMartrixIterationVote();
            string strR = textAbstract.TextRankKeyWordOutput();


        }
    }
}
